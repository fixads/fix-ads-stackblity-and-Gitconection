export interface Lead {
  name: string;
  email: string;
  company: string;
  phone: string;
  message: string;
}